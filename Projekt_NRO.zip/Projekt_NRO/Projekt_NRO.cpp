#define _USE_MATH_DEFINES
#include <vector>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <chrono>
#include <omp.h>
#include <ctime>
struct Tocka {
	int id_tocke;
	double x;
	double y;
};
struct Celice {
	int id_celice;
	std::vector<int> id_tock;
};
struct RobniPogoji {
	int st_pogoja;
	std::string vrsta_pogoja;
	double vrednost_pogoja;
	double pogoj_prestop;
	std::vector<int> id_tock;
};
int main()
{
	int st_pr = 2;
	int st_iter = 200;
	std::string jane = "D"; // D izvozi a in b, N jih ne izvozi
	std::vector<std::vector<double>> A;
	std::vector<double> b;
	std::string filename = "primer2mreza.txt";
	double k = 24;
	std::ifstream infile;
	infile.open(filename);
	std::string vrstica;
	std::getline(infile, vrstica);
	int n = std::stoi(vrstica.substr(6));
	std::vector<double> T;
	std::vector<Tocka> tocke;
	for (int i = 0; i < n; i++)
	{
		std::getline(infile, vrstica);
		size_t pos = vrstica.find(";");
		size_t pos2 = vrstica.find(",");
		Tocka toc;
		toc.id_tocke = std::stoi(vrstica.substr(0, pos));
		toc.x = std::stod(vrstica.substr(pos + 1, pos2 - pos - 1));
		toc.y = std::stod(vrstica.substr(pos2 + 1));
		tocke.push_back(toc);
	}
	std::getline(infile, vrstica);
	std::getline(infile, vrstica);
	int n_C = std::stoi(vrstica.substr(7));
	std::vector<Celice> celice;
	for (int i = 0; i < n_C; i++)
	{
		getline(infile, vrstica);
		Celice novaCelica;
		size_t pos = vrstica.find(";");
		novaCelica.id_celice = std::stoi(vrstica.substr(0, pos));
		std::stringstream ss(vrstica.substr(pos + 1));
		int id_toc;
		while (ss >> id_toc) {
			novaCelica.id_tock.push_back(id_toc);
			if (ss.peek() == ',') {
				ss.ignore();
			}
		}
		celice.push_back(novaCelica);
	}
	std::getline(infile, vrstica);
	std::getline(infile, vrstica);
	int n_RP = std::stoi(vrstica.substr(13));
	std::vector<RobniPogoji> robnipogoji;
	for (int i = 0; i < n_RP; i++)
	{
		RobniPogoji novRobniPogoj;
		std::getline(infile, vrstica);
		novRobniPogoj.st_pogoja = std::stoi(vrstica.substr(6, 1));
		novRobniPogoj.vrsta_pogoja = vrstica.substr(9);
		std::getline(infile, vrstica);
		size_t pos = vrstica.find(":");
		novRobniPogoj.vrednost_pogoja = std::stod(vrstica.substr(pos + 1));
		if (novRobniPogoj.vrsta_pogoja == "prestop")
		{
			std::getline(infile, vrstica);
			size_t pos = vrstica.find(":");
			novRobniPogoj.pogoj_prestop = std::stod(vrstica.substr(pos + 1));
		}
		else
		{
			novRobniPogoj.pogoj_prestop = 0;
		}
		std::getline(infile, vrstica);
		while (std::getline(infile, vrstica))
		{
			if (vrstica == "")
			{
				break;
			}
			else {
				novRobniPogoj.id_tock.push_back(std::stoi(vrstica));
			}
		}
		robnipogoji.push_back(novRobniPogoj);
	}
	infile.close();
	std::ofstream out("koncna_res" + std::to_string(st_pr) + ".vtk");
	out << "# vtk DataFile Version 3.0\n";
	out << "Test file\n";
	out << "ASCII\n";
	out << "DATASET UNSTRUCTURED_GRID\n";
	out << "POINTS " << n << " float\n";
	for (int i = 0; i < n; i++)
	{
		b.push_back(0);
	}
	for (int i = 0; i < n; i++)
	{
		A.push_back(b);
	}
	for (int iiT = 0; iiT < n; iiT++)
	{
		T.push_back(200);
	}
	double h;
	for (int Tocka_ID = 0; Tocka_ID < n; Tocka_ID++)
	{
		auto it = std::find_if(tocke.begin(), tocke.end(), [Tocka_ID](const Tocka& tocka) {
			return tocka.id_tocke == Tocka_ID;
			});
		double tockaX = it->x;
		double tockaY = it->y;
		out << tockaX << " " << tockaY << " 0" << '\n';
		std::string rpTIP = "notranja_tocka";
		double rpVREDNOST = 0;
		std::vector<RobniPogoji> pogojiZaTocko;
		for (const auto& pogoj : robnipogoji) {
			if (std::find(pogoj.id_tock.begin(), pogoj.id_tock.end(), Tocka_ID) != pogoj.id_tock.end()) {
				rpTIP = pogoj.vrsta_pogoja;
				rpVREDNOST = pogoj.vrednost_pogoja;
				if (rpTIP != "prestop")
				{
					h = 0;
					if (rpTIP == "temperatura")
					{
						A[Tocka_ID][Tocka_ID] = 1;
						b[Tocka_ID] = rpVREDNOST;
						T[Tocka_ID] = rpVREDNOST;
						continue;
					}
				}
				else {
					h = pogoj.pogoj_prestop;
				}
			}
		}
		int st_celic = 0;
		bool Ta = false;
		bool Tb = false;
		bool Tc = false;
		bool Td = false;
		bool At = false;
		bool Bt = false;
		bool Ct = false;
		bool Dt = false;
		double dx = 0;
		int idTa = n + 10;
		int idTb = n + 10;
		int idTc = n + 10;
		int idTd = n + 10;
		std::vector<int> sosedi;
		for (const auto& celica : celice) {
			if (std::find(celica.id_tock.begin(), celica.id_tock.end(), Tocka_ID) != celica.id_tock.end()) {
				st_celic += 1;
				for (const auto& sosed : celica.id_tock) {
					if (sosed != Tocka_ID) {
						if (std::find(sosedi.begin(), sosedi.end(), sosed) == sosedi.end())
						{
							sosedi.push_back(sosed);
							auto itt = std::find_if(tocke.begin(), tocke.end(), [sosed](const Tocka& tocka) {
								return tocka.id_tocke == sosed;
								});
							double sosedX = itt->x;
							double sosedY = itt->y;
							int sosedID = itt->id_tocke;
							sosedX = std::round(std::pow(10, 2) * sosedX) / 100;
							tockaX = std::round(std::pow(10, 2) * tockaX) / 100;
							sosedY = std::round(std::pow(10, 2) * sosedY) / 100;
							tockaY = std::round(std::pow(10, 2) * tockaY) / 100;
							if (sosedX == tockaX || sosedY == tockaY)
							{
								dx = sqrt(pow(sosedX - tockaX, 2) + pow(sosedY - tockaY, 2));
								if (sosedX < tockaX) {
									idTb = sosedID;
									Tb = true;
								}
								else if (sosedX > tockaX) {
									idTc = sosedID;
									Tc = true;
								}
								else if (sosedY > tockaY) {
									idTa = sosedID;
									Ta = true;
								}
								else if (sosedY < tockaY) {
									idTd = sosedID;
									Td = true;
								}
								else {
									std::cout << sosedID << " ni sosed " << Tocka_ID << std::endl;
								}
							}
							else {
								if (sosedX < tockaX && sosedY > tockaY)
								{
									At = true;
								}
								else if (sosedX > tockaX && sosedY > tockaY)
								{
									Bt = true;
								}
								else if (sosedX < tockaX && sosedY < tockaY)
								{
									Ct = true;
								}
								else if (sosedX > tockaX && sosedY < tockaY)
								{
									Dt = true;
								}
							}
						}
					}
				}
			}
		}
		if (st_celic >= 4)
		{
			A[Tocka_ID][Tocka_ID] = -4;
			A[Tocka_ID][idTa] = 1;
			A[Tocka_ID][idTb] = 1;
			A[Tocka_ID][idTc] = 1;
			A[Tocka_ID][idTd] = 1;
			b[Tocka_ID] = 0;
		}
		else if (st_celic == 2)
		{
			if (rpTIP == "prestop") //r.p.
			{
				if (Ct == true && Dt == true) //zgori
				{
					A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 2);
					A[Tocka_ID][idTd] = 2;
					A[Tocka_ID][idTb] = 2;
					A[Tocka_ID][idTc] = 2;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
				else if (At == true && Ct == true) //desno
				{
					A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 2);
					A[Tocka_ID][idTa] = 2;
					A[Tocka_ID][idTb] = 2;
					A[Tocka_ID][idTd] = 2;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
				else if (Bt == true && Dt == true) //levo
				{
					A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 2);
					A[Tocka_ID][idTa] = 2;
					A[Tocka_ID][idTc] = 2;
					A[Tocka_ID][idTd] = 2;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
				else if (At == true && Bt == true) //spodi
				{
					A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 2);
					A[Tocka_ID][idTa] = 2;
					A[Tocka_ID][idTb] = 2;
					A[Tocka_ID][idTc] = 2;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
			}
			else if (rpTIP == "toplotni tok") //r.p
			{
				if (Ct == true && Dt == true) //zgori
				{
					A[Tocka_ID][Tocka_ID] = -4;
					A[Tocka_ID][idTb] = 1;
					A[Tocka_ID][idTc] = 1;
					A[Tocka_ID][idTd] = 2;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
				else if (At == true && Ct == true) //desno
				{
					A[Tocka_ID][Tocka_ID] = -4;
					A[Tocka_ID][idTa] = 1;
					A[Tocka_ID][idTb] = 2;
					A[Tocka_ID][idTd] = 1;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
				else if (Bt == true && Dt == true) //levo
				{
					A[Tocka_ID][Tocka_ID] = -4;
					A[Tocka_ID][idTa] = 1;
					A[Tocka_ID][idTc] = 2;
					A[Tocka_ID][idTd] = 1;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
				else if (At == true && Bt == true) //spodi
				{
					A[Tocka_ID][Tocka_ID] = -4;
					A[Tocka_ID][idTa] = 2;
					A[Tocka_ID][idTb] = 1;
					A[Tocka_ID][idTc] = 1;
					b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
				}
			}
		}
		else if (st_celic == 1)
		{
			if (Dt == true) //zgori levo
			{
				A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 1);
				A[Tocka_ID][idTc] = 1;
				A[Tocka_ID][idTd] = 1;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
			else if (Ct == true) //zgori desno
			{
				A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 1);
				A[Tocka_ID][idTb] = 1;
				A[Tocka_ID][idTd] = 1;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
			else if (Bt == true) //spodi levo
			{
				A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 1);
				A[Tocka_ID][idTa] = 1;
				A[Tocka_ID][idTc] = 1;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
			else if (At == true) //spodi desno
			{
				A[Tocka_ID][Tocka_ID] = -2 * (h * dx / k + 1);
				A[Tocka_ID][idTa] = 1;
				A[Tocka_ID][idTb] = 1;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
		}
		else if (st_celic == 3)
		{
			if (At == true && Bt == true && Ct == true) //zgori levo
			{
				A[Tocka_ID][Tocka_ID] = -2 * (3 + h * dx / k);
				A[Tocka_ID][idTa] = 2;
				A[Tocka_ID][idTb] = 2;
				A[Tocka_ID][idTc] = 1;
				A[Tocka_ID][idTd] = 1;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
			else if (At == true && Bt == true && Dt == true) //zgori desno
			{
				A[Tocka_ID][Tocka_ID] = -2 * (3 + h * dx / k);
				A[Tocka_ID][idTa] = 2;
				A[Tocka_ID][idTb] = 1;
				A[Tocka_ID][idTc] = 2;
				A[Tocka_ID][idTd] = 1;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
			else if (At == true && Ct == true && Dt == true) //spodi levo
			{
				A[Tocka_ID][Tocka_ID] = -2 * (3 + h * dx / k);
				A[Tocka_ID][idTa] = 1;
				A[Tocka_ID][idTb] = 2;
				A[Tocka_ID][idTc] = 1;
				A[Tocka_ID][idTd] = 2;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
			else if (Bt == true && Ct == true && Dt == true) //spodi desno
			{
				A[Tocka_ID][Tocka_ID] = -2 * (3 + h * dx / k);
				A[Tocka_ID][idTa] = 1;
				A[Tocka_ID][idTb] = 1;
				A[Tocka_ID][idTc] = 2;
				A[Tocka_ID][idTd] = 2;
				b[Tocka_ID] = -2 * h * dx / k * rpVREDNOST;
			}
		}
	}
	if (jane == "d" || jane == "D") {
		std::ofstream fileA("mat_A" + std::to_string(st_pr) + ".cvs");
		for (const auto& row : A)
		{
			for (size_t i = 0; i < row.size() - 1; i++)
			{
				fileA << row[i] << ",";
			}
			fileA << "\n";
		}
		fileA.close();
		std::ofstream fileB("vekt_B" + std::to_string(st_pr) + ".cvs");
		for (size_t i = 0; i < b.size(); ++i) {
			fileB << b[i] << "\n";
		}
		fileB.close();
	}
	out << "\n";
	out << "CELLS " << n_C << " " << n_C * 5 << "\n";
	for (int i_cell = 0; i_cell < n_C; i_cell++)
	{
		out << "4" << " " << celice[i_cell].id_tock[0] << " " << celice[i_cell].id_tock[1] << " " <<
			celice[i_cell].id_tock[2] << " " << celice[i_cell].id_tock[3] << '\n';
	}
	out << "\n";
	out << "CELL_TYPES " << n_C << "\n";
	for (int i_cell = 0; i_cell < n_C; i_cell++)
	{
		out << "7" << '\n';
	}
	out << "\n";
	for (int ii = 0; ii < st_iter; ii++)
	{
		for (int i = 0; i < n; i++)
		{
			double d = b[i];
			for (int j = 0; j < n; j++)
			{
				if (i != j)
				{
					d -= A[i][j] * T[j];
				}
			}
			if (A[i][i] != 0)
			{
				T[i] = d / A[i][i];
			}
		}
	}
	out << "POINT_DATA " << n << "\n";
	out << "SCALARS T float 1\n";
	out << "LOOKUP_TABLE default\n";
	for (int i_point = 0; i_point < n; i_point++) out << T[i_point] << '\n';
	out << "CELL_DATA " << n_C << "\n";
	out << "SCALARS V float 1\n";
	out << "LOOKUP_TABLE default\n";
	std::vector<double> A_celice;
	for (int i = 0; i < n_C; i++)
	{
		out << abs((tocke[celice[i].id_tock[2]].x - tocke[celice[i].id_tock[0]].x) * (tocke[celice[i].id_tock[2]].y - tocke[celice[i].id_tock[0]].y)) << '\n';
	}
	out.close();
	return 1;
}